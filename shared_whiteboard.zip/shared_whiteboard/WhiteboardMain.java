public class WhiteboardMain {
    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            System.out.println("Usage:");
            System.out.println("  Create manager + server: java WhiteboardMain CreateWhiteBoard <serverIP> <serverPort> <username>");
            System.out.println("  Join existing:           java WhiteboardMain JoinWhiteBoard   <serverIP> <serverPort> <username>");
            System.exit(1);
        }
        String mode = args[0];
        String host = args[1];
        int port = Integer.parseInt(args[2]);
        String username = args[3];

        if (mode.equalsIgnoreCase("CreateWhiteBoard")) {
            // start server and then start client connecting to it (manager)
            Server server = new Server(port);
            server.start();
            System.out.println("[MAIN] Server started, waiting for initialization...");
            // Increased sleep time to ensure server is fully ready
            Thread.sleep(1000);
            System.out.println("[MAIN] Connecting manager client to " + host + ":" + port);
            Client client = new Client(host, port, username, true);
            client.startAndShowGUI();
        } else if (mode.equalsIgnoreCase("JoinWhiteBoard")) {
            Client client = new Client(host, port, username, false);
            client.startAndShowGUI();
        } else {
            System.out.println("Unknown mode: " + mode);
            System.exit(1);
        }
    }
}