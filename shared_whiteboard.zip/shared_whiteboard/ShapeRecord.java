// ShapeRecord.java
import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Serializable description of a shape to draw.
 */
public class ShapeRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    public String shapeType;         // LINE, RECT, CIRCLE, TRIANGLE, FREE, TEXT, ERASER
    public int x1, y1, x2, y2;
    public List<Integer> xPoints;
    public List<Integer> yPoints;
    public int colorRGB;
    public int strokeWidth;
    public String text;

    // Factory methods
    public static ShapeRecord line(int x1,int y1,int x2,int y2, Color c,int stroke) {
        ShapeRecord s = new ShapeRecord();
        s.shapeType="LINE";
        s.x1=x1; s.y1=y1; s.x2=x2; s.y2=y2;
        s.colorRGB=c.getRGB(); s.strokeWidth=stroke;
        return s;
    }
    public static ShapeRecord rect(int x1,int y1,int x2,int y2, Color c,int stroke) {
        ShapeRecord s = new ShapeRecord();
        s.shapeType="RECT";
        s.x1=Math.min(x1,x2); s.y1=Math.min(y1,y2);
        s.x2=Math.abs(x2-x1); s.y2=Math.abs(y2-y1);
        s.colorRGB=c.getRGB(); s.strokeWidth=stroke;
        return s;
    }
    public static ShapeRecord circle(int x1,int y1,int x2,int y2, Color c,int stroke) {
        ShapeRecord s = new ShapeRecord();
        s.shapeType="CIRCLE";
        s.x1=Math.min(x1,x2); s.y1=Math.min(y1,y2);
        s.x2=Math.abs(x2-x1); s.y2=Math.abs(y2-y1);
        s.colorRGB=c.getRGB(); s.strokeWidth=stroke;
        return s;
    }
    public static ShapeRecord triangle(int x1,int y1,int x2,int y2, Color c,int stroke) {
        ShapeRecord s = new ShapeRecord();
        s.shapeType="TRIANGLE";
        s.x1=x1; s.y1=y1; s.x2=x2; s.y2=y2;
        s.colorRGB=c.getRGB(); s.strokeWidth=stroke;
        return s;
    }
    public static ShapeRecord free(List<Integer> xs,List<Integer> ys,Color c,int stroke) {
        ShapeRecord s = new ShapeRecord();
        s.shapeType="FREE";
        s.xPoints=new ArrayList<>(xs);
        s.yPoints=new ArrayList<>(ys);
        s.colorRGB=c.getRGB(); s.strokeWidth=stroke;
        return s;
    }
    public static ShapeRecord text(int x,int y,String txt,Color c,int stroke) {
        ShapeRecord s=new ShapeRecord();
        s.shapeType="TEXT";
        s.x1=x; s.y1=y;
        s.text=txt;
        s.colorRGB=c.getRGB(); s.strokeWidth=stroke;
        return s;
    }
    public static ShapeRecord eraser(List<Integer> xs,List<Integer> ys,int stroke) {
        ShapeRecord s=new ShapeRecord();
        s.shapeType="ERASER";
        s.xPoints=new ArrayList<>(xs);
        s.yPoints=new ArrayList<>(ys);
        s.colorRGB=Color.WHITE.getRGB();
        s.strokeWidth=stroke;
        return s;
    }

    // Draw on client canvas
    public void draw(Graphics2D g2d) {
        Color old = g2d.getColor();
        Stroke oldStroke = g2d.getStroke();
        g2d.setColor(new Color(colorRGB));
        g2d.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        switch (shapeType) {
            case "LINE":
                g2d.drawLine(x1,y1,x2,y2);
                break;
            case "RECT":
                g2d.drawRect(x1,y1,x2,y2);
                break;
            case "CIRCLE":
                g2d.drawOval(x1,y1,x2,y2);
                break;
            case "TRIANGLE": {
                int ax = x1;
                int bx = x2;
                int cx = (x1+x2)/2;
                int cy = y1 - Math.abs(y2-y1);
                Polygon p = new Polygon(new int[]{ax,bx,cx}, new int[]{y1,y1,cy}, 3);
                g2d.drawPolygon(p);
                break;
            }
            case "FREE":
            case "ERASER":
                if (xPoints!=null && xPoints.size()>1) {
                    for (int i=1;i<xPoints.size();i++) {
                        g2d.drawLine(xPoints.get(i-1),yPoints.get(i-1),xPoints.get(i),yPoints.get(i));
                    }
                }
                break;
            case "TEXT":
                if (text!=null) {
                    Font oldF = g2d.getFont();
                    g2d.setFont(oldF.deriveFont((float)Math.max(12, strokeWidth*4)));
                    g2d.drawString(text, x1, y1);
                    g2d.setFont(oldF);
                }
                break;
        }

        g2d.setColor(old);
        g2d.setStroke(oldStroke);
    }
}
