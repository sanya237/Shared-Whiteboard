import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.List;

public class Client {
    private final String host;
    private final int port;
    private final String username;
    private final boolean isManagerMode;

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    private JFrame frame;
    private CanvasPanel canvas;
    private DefaultListModel<String> userListModel = new DefaultListModel<>();
    private DefaultListModel<String> chatModel = new DefaultListModel<>();
    private JLabel statusLabel;
    private boolean isApproved = false;

    private Color currentColor = Color.BLACK;
    private String currentTool = "FREE";
    private int strokeWidth = 2;

    private final List<ShapeRecord> shapes = Collections.synchronizedList(new ArrayList<>());
    private final List<Integer> freeX = new ArrayList<>(), freeY = new ArrayList<>();
    private File currentSaveFile = null;

    public Client(String host,int port,String username,boolean isManagerMode){
        this.host=host; this.port=port; this.username=username; this.isManagerMode=isManagerMode;
    }

    public void startAndShowGUI() throws Exception {
        System.out.println("[CLIENT] Attempting to connect to " + host + ":" + port);
        try {
            socket = new Socket(host, port);
            System.out.println("[CLIENT] Connected successfully!");
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(socket.getInputStream());

            send(new Message(MessageType.JOIN_REQUEST, username, username));
            
            if (isManagerMode) {
                isApproved = true;
            }
            
            SwingUtilities.invokeAndWait(this::buildGUI);
            new Thread(this::listenLoop).start();
        } catch (ConnectException ce) {
            System.err.println("[CLIENT] Connection refused: " + ce.getMessage());
            JOptionPane.showMessageDialog(null, "Connection closed.\nServer not reachable at " + host + ":" + port);
            throw ce;
        } catch (IOException ioe) {
            System.err.println("[CLIENT] IO Error: " + ioe.getMessage());
            ioe.printStackTrace();
            JOptionPane.showMessageDialog(null, "Connection closed.\nError: " + ioe.getMessage());
            throw ioe;
        }
    }

    private void buildGUI(){
        frame=new JFrame("Whiteboard - "+username+(isManagerMode?" (Manager)":""));
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1100,700);
        frame.setLayout(new BorderLayout());
        
        if (!isApproved) {
            JPanel waitingPanel = new JPanel(new BorderLayout());
            JLabel waitingLabel = new JLabel("Waiting for manager approval...", SwingConstants.CENTER);
            waitingLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            waitingLabel.setForeground(new Color(100, 100, 100));
            waitingPanel.add(waitingLabel, BorderLayout.CENTER);
            frame.add(waitingPanel, BorderLayout.CENTER);
            frame.setVisible(true);
            frame.addWindowListener(new WindowAdapter(){
                public void windowClosing(WindowEvent e){ cleanupAndExit(); }
            });
            return;
        }
        
        buildFullGUI();
    }
    
    private void buildFullGUI(){
        JPanel left=new JPanel();
        left.setLayout(new BoxLayout(left,BoxLayout.Y_AXIS));
        left.setBorder(new EmptyBorder(5,5,5,5));

        ButtonGroup tg=new ButtonGroup();
        String[] tools={"FREE","LINE","RECT","CIRCLE","TRIANGLE","TEXT","ERASER"};
        for(String t:tools){
            JToggleButton b=new JToggleButton(t);
            if(t.equals("FREE")) b.setSelected(true);
            tg.add(b); left.add(b);
            b.addActionListener(e->currentTool=t);
        }

        left.add(new JLabel("Stroke"));
        JSlider stroke=new JSlider(1,16,strokeWidth);
        stroke.addChangeListener(e->strokeWidth=stroke.getValue());
        left.add(stroke);

        left.add(new JLabel("Colors"));
        JPanel cp=new JPanel(new GridLayout(4,4,3,3));
        for(Color c:palette16()){
            JButton cb = new JButton();
            cb.setBackground(c);
            cb.setOpaque(true);
            cb.setBorderPainted(false);
            cb.setPreferredSize(new Dimension(30,30));
            cb.addActionListener(e -> currentColor = c);
            cp.add(cb);
        }
        left.add(cp);

        left.add(new JLabel("Users"));
        JList<String> userListUI=new JList<>(userListModel);
        JScrollPane userScrollPane = new JScrollPane(userListUI);
        userScrollPane.setPreferredSize(new Dimension(150, 100));
        left.add(userScrollPane);

        if(isManagerMode){
            JButton kick=new JButton("Kick");
            kick.addActionListener(e->{
                String target=userListUI.getSelectedValue();
                if(target!=null && !target.equals(username)){
                    int r=JOptionPane.showConfirmDialog(frame,"Kick "+target+"?","Confirm",JOptionPane.YES_NO_OPTION);
                    if(r==JOptionPane.YES_OPTION) send(new Message(MessageType.KICK,target,username));
                }
            });
            left.add(kick);
        }

        frame.add(left,BorderLayout.WEST);

        canvas=new CanvasPanel();
        JPanel centerPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel(" ");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        statusLabel.setFont(new Font("SansSerif", Font.ITALIC, 11));
        statusLabel.setForeground(new Color(100, 100, 100));
        centerPanel.add(statusLabel, BorderLayout.NORTH);
        centerPanel.add(canvas, BorderLayout.CENTER);
        frame.add(centerPanel,BorderLayout.CENTER);

        JPanel right=new JPanel(new BorderLayout());
        JList<String> chatList=new JList<>(chatModel);
        right.add(new JScrollPane(chatList),BorderLayout.CENTER);

        JPanel ci=new JPanel(new BorderLayout());
        JTextField cf=new JTextField();
        JButton sendBtn=new JButton("Send");
        sendBtn.addActionListener(e->{
            String txt=cf.getText().trim();
            if(!txt.isEmpty()){
                SharedPayloads.ChatMessage cm=new SharedPayloads.ChatMessage(username,txt);
                send(new Message(MessageType.CHAT,cm,username));
                cf.setText("");
            }
        });
        ci.add(cf,BorderLayout.CENTER);
        ci.add(sendBtn,BorderLayout.EAST);
        right.add(ci,BorderLayout.SOUTH);
        right.setPreferredSize(new Dimension(250,0));
        frame.add(right,BorderLayout.EAST);

        JMenuBar mb=new JMenuBar();
        JMenu file=new JMenu("File");

        if(isManagerMode){
            JMenuItem n=new JMenuItem("New");
            n.addActionListener(e->{
                if(JOptionPane.showConfirmDialog(frame,"Create new whiteboard?","Confirm",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                    shapes.clear(); canvas.repaint();
                    send(new Message(MessageType.NEW_BOARD,null,username));
                }
            });

            JMenuItem open=new JMenuItem("Open...");
            open.addActionListener(e->{
                JFileChooser fc=new JFileChooser();
                if(fc.showOpenDialog(frame)==JFileChooser.APPROVE_OPTION){
                    try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fc.getSelectedFile()))){
                        @SuppressWarnings("unchecked")
                        List<ShapeRecord> loaded=(List<ShapeRecord>)ois.readObject();
                        shapes.clear(); shapes.addAll(loaded); canvas.repaint();
                        send(new Message(MessageType.FILE_OPEN,new SharedPayloads.FullState(new ArrayList<>(shapes)),username));
                        currentSaveFile=fc.getSelectedFile();
                    }catch(Exception ex){ JOptionPane.showMessageDialog(frame,"Open failed: "+ex.getMessage()); }
                }
            });

            JMenuItem save=new JMenuItem("Save");
            save.addActionListener(e->doSave(false));

            JMenuItem saveAs=new JMenuItem("Save As...");
            saveAs.addActionListener(e->doSave(true));

            JMenuItem close=new JMenuItem("Close Board");
            close.addActionListener(e->{
                if(JOptionPane.showConfirmDialog(frame,"Close the board for everyone?","Close",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                    send(new Message(MessageType.CLOSE_BOARD,null,username));
                }
            });

            file.add(n); file.add(open); file.add(save); file.add(saveAs);
            file.addSeparator(); file.add(close);
        }

        mb.add(file);
        frame.setJMenuBar(mb);
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                if(isManagerMode){
                    int r=JOptionPane.showConfirmDialog(frame,"You are the manager. Close board for all?","Exit",JOptionPane.YES_NO_OPTION);
                    if(r==JOptionPane.YES_OPTION) send(new Message(MessageType.CLOSE_BOARD,null,username));
                }
                cleanupAndExit();
            }
        });
    }

    private void doSave(boolean saveAs){
        try{
            if(saveAs || currentSaveFile==null){
                JFileChooser fc=new JFileChooser();
                if(fc.showSaveDialog(frame)==JFileChooser.APPROVE_OPTION) currentSaveFile=fc.getSelectedFile();
                else return;
            }
            try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(currentSaveFile))){
                oos.writeObject(new ArrayList<>(shapes));
            }
            JOptionPane.showMessageDialog(frame,"Saved to "+currentSaveFile.getAbsolutePath());
        }catch(Exception ex){ JOptionPane.showMessageDialog(frame,"Save failed: "+ex.getMessage()); }
    }

    private void listenLoop(){
        try{
            while(true){
                Message m=(Message)in.readObject();
                if(m==null) break;
                handleServerMessage(m);
            }
        }catch(EOFException eof){
            System.out.println("[CLIENT] Server closed connection");
        }catch(Exception e){
            System.err.println("[CLIENT] Connection error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleServerMessage(Message m){
        switch(m.type){
            case JOIN_RESPONSE:{
                SharedPayloads.JoinResponse jr=(SharedPayloads.JoinResponse)m.payload;
                if(!jr.accepted){
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(frame,"Join rejected: "+jr.reason);
                        cleanupAndExit();
                    });
                }else{
                    isApproved = true;
                    SwingUtilities.invokeLater(() -> {
                        frame.getContentPane().removeAll();
                        buildFullGUI();
                        frame.revalidate();
                        frame.repaint();
                        chatModel.addElement("[SYSTEM] "+jr.reason);
                    });
                }
                break;
            }
            case MANAGER_APPROVAL_REQUEST:{
                if(!isManagerMode) break;
                String who=(String)m.payload;
                SwingUtilities.invokeLater(()->{
                    int r=JOptionPane.showConfirmDialog(frame,who+" wants to join. Accept?","Join Request",JOptionPane.YES_NO_OPTION);
                    send(new Message(MessageType.MANAGER_APPROVAL_RESULT,new SharedPayloads.ApprovalResult(who,r==JOptionPane.YES_OPTION),username));
                });
                break;
            }
            case FULL_STATE:{
                SharedPayloads.FullState fs=(SharedPayloads.FullState)m.payload;
                shapes.clear(); shapes.addAll(fs.shapes);
                if(canvas!=null) canvas.repaint();
                break;
            }
            case DRAW:{
                ShapeRecord sr=(ShapeRecord)m.payload;
                shapes.add(sr);
                if(canvas!=null) canvas.repaint();
                break;
            }
            case CHAT:{
                SharedPayloads.ChatMessage cm=(SharedPayloads.ChatMessage)m.payload;
                chatModel.addElement(cm.fromUser+": "+cm.message);
                break;
            }
            case USER_LIST_UPDATE:{
                @SuppressWarnings("unchecked")
                List<String> list=(List<String>)m.payload;
                SwingUtilities.invokeLater(()->{
                    userListModel.clear();
                    for(String s:list) userListModel.addElement(s);
                });
                break;
            }
            case KICKED:{
                JOptionPane.showMessageDialog(frame,"You have been kicked by manager.");
                cleanupAndExit();
                break;
            }
            case SHUTDOWN:{
                JOptionPane.showMessageDialog(frame,"Board closed: "+m.payload);
                cleanupAndExit();
                break;
            }
            case DRAWING_ACTIVITY:{
                SharedPayloads.DrawingActivity da = (SharedPayloads.DrawingActivity)m.payload;
                if(statusLabel!=null){
                    SwingUtilities.invokeLater(() -> {
                        if (da.isDrawing) {
                            statusLabel.setText(da.username + " is drawing...");
                        } else {
                            statusLabel.setText(" ");
                        }
                    });
                }
                break;
            }
            default: break;
        }
    }

    private synchronized void send(Message m){
        try{
            out.writeObject(m);
            out.flush();
            out.reset();
        }catch(IOException e){
            System.err.println("[CLIENT] Failed to send message");
        }
    }

    private void cleanupAndExit(){
        try{ socket.close(); }catch(IOException ignored){}
        System.exit(0);
    }

    private Color[] palette16(){
        return new Color[]{
            Color.BLACK,Color.DARK_GRAY,Color.GRAY,Color.LIGHT_GRAY,
            Color.WHITE,Color.RED,Color.PINK,Color.ORANGE,
            Color.YELLOW,Color.GREEN,Color.MAGENTA,Color.CYAN,
            new Color(102,51,0), new Color(153,0,153), new Color(0,102,102), new Color(0,51,102)
        };
    }

    class CanvasPanel extends JPanel{
        int sx,sy;
        CanvasPanel(){
            setBackground(Color.WHITE);
            MouseAdapter ma=new MouseAdapter(){
                public void mousePressed(MouseEvent e){
                    if (!isApproved) return;
                    sx=e.getX(); sy=e.getY();
                    send(new Message(MessageType.DRAWING_ACTIVITY, new SharedPayloads.DrawingActivity(username, true), username));
                    
                    if(currentTool.equals("FREE")||currentTool.equals("ERASER")){
                        freeX.clear(); freeY.clear();
                        freeX.add(sx); freeY.add(sy);
                    }else if(currentTool.equals("TEXT")){
                        String txt=JOptionPane.showInputDialog(frame,"Enter text:");
                        if(txt!=null && !txt.trim().isEmpty()){
                            ShapeRecord sr=ShapeRecord.text(sx,sy,txt,currentColor,Math.max(2,strokeWidth));
                            shapes.add(sr);
                            send(new Message(MessageType.DRAW,sr,username));
                            repaint();
                        }
                        send(new Message(MessageType.DRAWING_ACTIVITY, new SharedPayloads.DrawingActivity(username, false), username));
                    }
                }
                public void mouseDragged(MouseEvent e){
                    if (!isApproved) return;
                    int mx=e.getX(), my=e.getY();
                    if(currentTool.equals("FREE")||currentTool.equals("ERASER")){
                        freeX.add(mx); freeY.add(my);
                        repaint();
                    }else repaint();
                }
                public void mouseReleased(MouseEvent e){
                    if (!isApproved) return;
                    int ex=e.getX(), ey=e.getY();
                    ShapeRecord sr=null;
                    switch(currentTool){
                        case "LINE": sr=ShapeRecord.line(sx,sy,ex,ey,currentColor,strokeWidth); break;
                        case "RECT": sr=ShapeRecord.rect(sx,sy,ex,ey,currentColor,strokeWidth); break;
                        case "CIRCLE": sr=ShapeRecord.circle(sx,sy,ex,ey,currentColor,strokeWidth); break;
                        case "TRIANGLE": sr=ShapeRecord.triangle(sx,sy,ex,ey,currentColor,strokeWidth); break;
                        case "FREE": sr=ShapeRecord.free(new ArrayList<>(freeX),new ArrayList<>(freeY),currentColor,strokeWidth); break;
                        case "ERASER": sr=ShapeRecord.eraser(new ArrayList<>(freeX),new ArrayList<>(freeY),Math.max(4,strokeWidth*3)); break;
                    }
                    if(sr!=null){
                        shapes.add(sr);
                        send(new Message(MessageType.DRAW,sr,username));
                        repaint();
                    }
                    freeX.clear(); freeY.clear();
                    send(new Message(MessageType.DRAWING_ACTIVITY, new SharedPayloads.DrawingActivity(username, false), username));
                }
            };
            addMouseListener(ma);
            addMouseMotionListener(ma);
        }

        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            if (!isApproved) return;
            Graphics2D g2=(Graphics2D)g.create();
            synchronized(shapes){
                for(ShapeRecord s:shapes) s.draw(g2);
            }
            if((currentTool.equals("FREE")||currentTool.equals("ERASER")) && freeX.size()>1){
                ShapeRecord tmp = currentTool.equals("FREE")
                        ? ShapeRecord.free(freeX,freeY,currentColor,strokeWidth)
                        : ShapeRecord.eraser(freeX,freeY,Math.max(4,strokeWidth*3));
                tmp.draw(g2);
            }
            g2.dispose();
        }
    }
}