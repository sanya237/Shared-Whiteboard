// Message.java
import java.io.Serializable;

public class Message implements Serializable {
    private static final long serialVersionUID = 1L;

    public final MessageType type;
    public final Object payload;
    public final String from;

    public Message(MessageType type, Object payload, String from) {
        this.type = type;
        this.payload = payload;
        this.from = from;
    }

    @Override
    public String toString() {
        return "Message{" + type + ", from=" + from + "}";
    }
}
