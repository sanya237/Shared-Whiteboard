// Server.java
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    private final int port;
    private ServerSocket serverSocket;
    private final Map<String, ClientHandler> clients = new ConcurrentHashMap<>();
    private final List<ShapeRecord> shapes = Collections.synchronizedList(new ArrayList<>());
    private final Map<String, ClientHandler> pending = new ConcurrentHashMap<>();
    private volatile String managerUsername = null;

    public Server(int port) { this.port = port; }

    public void start() throws IOException {
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(port));
        System.out.println("[SERVER] Listening on port " + port);
        
        new Thread(() -> {
            try {
                while (!serverSocket.isClosed()) {
                    Socket s = serverSocket.accept();
                    System.out.println("[SERVER] New connection from " + s.getRemoteSocketAddress());
                    new ClientHandler(s).start();
                }
            } catch (IOException e) {
                if (!serverSocket.isClosed()) {
                    System.err.println("[SERVER] Error accepting connection: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void stop() {
        try { 
            System.out.println("[SERVER] Stopping server...");
            serverSocket.close(); 
        } catch (IOException ignored) {}
        for (ClientHandler h : clients.values()) h.closeSilently();
    }

    private void broadcast(Message m, String exclude) {
        for (Map.Entry<String,ClientHandler> e:clients.entrySet()) {
            if (exclude!=null && exclude.equals(e.getKey())) continue;
            e.getValue().send(m);
        }
    }

    private void sendUserListToAll() {
        broadcast(new Message(MessageType.USER_LIST_UPDATE,new ArrayList<>(clients.keySet()),"SERVER"),null);
    }

    private class ClientHandler {
        final Socket socket;
        ObjectOutputStream out;
        ObjectInputStream in;
        String username;
        boolean isManager=false;

        ClientHandler(Socket s) throws IOException {
            socket=s;
            out=new ObjectOutputStream(s.getOutputStream());
            out.flush();
            in=new ObjectInputStream(s.getInputStream());
        }

        void start() {
            new Thread(() -> {
                try {
                    Message first = (Message) in.readObject();
                    if (first.type!=MessageType.JOIN_REQUEST) {
                        send(new Message(MessageType.JOIN_RESPONSE,new SharedPayloads.JoinResponse(false,"Bad first message"),"SERVER"));
                        closeSilently(); return;
                    }
                    username=(String) first.payload;
                    System.out.println("[SERVER] Join request from: " + username);

                    synchronized(Server.this) {
                        // Check for duplicate username
                        if (clients.containsKey(username) || pending.containsKey(username)) {
                            System.out.println("[SERVER] Rejected " + username + " - username already exists");
                            send(new Message(MessageType.JOIN_RESPONSE,new SharedPayloads.JoinResponse(false,"Username '" + username + "' is already taken. Please choose a different name."),"SERVER"));
                            closeSilently();
                            return;
                        }
                        
                        if (managerUsername==null) {
                            managerUsername=username;
                            isManager=true;
                            clients.put(username,this);
                            System.out.println("[SERVER] " + username + " is now the manager");
                            send(new Message(MessageType.JOIN_RESPONSE,new SharedPayloads.JoinResponse(true,"You are manager"),"SERVER"));
                            send(new Message(MessageType.FULL_STATE,new SharedPayloads.FullState(new ArrayList<>(shapes)),"SERVER"));
                            sendUserListToAll();
                        } else {
                            System.out.println("[SERVER] " + username + " requires approval from manager");
                            pending.put(username,this);
                            ClientHandler mgr=clients.get(managerUsername);
                            if (mgr!=null) {
                                mgr.send(new Message(MessageType.MANAGER_APPROVAL_REQUEST,username,"SERVER"));
                            } else {
                                send(new Message(MessageType.JOIN_RESPONSE,new SharedPayloads.JoinResponse(false,"No manager"),"SERVER"));
                                closeSilently();
                            }
                        }
                    }

                    while (!socket.isClosed()) {
                        Message m = (Message) in.readObject();
                        handle(m,this);
                    }
                } catch (EOFException eof) {
                    System.out.println("[SERVER] Client " + username + " disconnected");
                } catch (Exception e) {
                    System.err.println("[SERVER] Error handling client " + username + ": " + e.getMessage());
                } finally { cleanup(); }
            }).start();
        }

        void send(Message m) {
            try {
                synchronized(out) {
                    out.writeObject(m);
                    out.flush();
                    out.reset();
                }
            } catch(IOException e){ 
                System.err.println("[SERVER] Failed to send to " + username);
                cleanup(); 
            }
        }

        void closeSilently() { 
            try { socket.close(); } catch(IOException ignored){}
        }

        void cleanup() {
            try { socket.close(); } catch(IOException ignored){}
            pending.remove(username);
            clients.remove(username);
            if (isManager) {
                System.out.println("[SERVER] Manager left, shutting down");
                broadcast(new Message(MessageType.SHUTDOWN,"Manager closed board","SERVER"),null);
                stop();
            } else {
                if (username != null) {
                    System.out.println("[SERVER] User " + username + " left");
                }
                sendUserListToAll();
            }
        }
    }

    private void handle(Message m, ClientHandler src) {
        switch(m.type) {
            case MANAGER_APPROVAL_RESULT: {
                SharedPayloads.ApprovalResult ar = (SharedPayloads.ApprovalResult) m.payload;
                ClientHandler h = pending.remove(ar.username);
                if (h!=null) {
                    if (ar.accept) {
                        System.out.println("[SERVER] Manager approved " + ar.username);
                        clients.put(ar.username,h);
                        h.send(new Message(MessageType.JOIN_RESPONSE,new SharedPayloads.JoinResponse(true,"Approved"),"SERVER"));
                        h.send(new Message(MessageType.FULL_STATE,new SharedPayloads.FullState(new ArrayList<>(shapes)),"SERVER"));
                        sendUserListToAll();
                    } else {
                        System.out.println("[SERVER] Manager rejected " + ar.username);
                        h.send(new Message(MessageType.JOIN_RESPONSE,new SharedPayloads.JoinResponse(false,"Rejected"),"SERVER"));
                        h.closeSilently();
                    }
                }
                break;
            }
            case DRAW:
                shapes.add((ShapeRecord)m.payload);
                broadcast(new Message(MessageType.DRAW,m.payload,m.from), m.from);
                break;
            case CHAT:
                broadcast(new Message(MessageType.CHAT,m.payload,m.from),null);
                break;
            case DRAWING_ACTIVITY:
                // Broadcast who is currently drawing
                broadcast(new Message(MessageType.DRAWING_ACTIVITY,m.payload,m.from),m.from);
                break;
            case KICK:
                String target=(String)m.payload;
                ClientHandler kicked=clients.remove(target);
                if(kicked!=null){
                    System.out.println("[SERVER] Kicking user: " + target);
                    kicked.send(new Message(MessageType.KICKED,"You were kicked","SERVER"));
                    kicked.closeSilently();
                    sendUserListToAll();
                }
                break;
            case FILE_OPEN:
                SharedPayloads.FullState fs = (SharedPayloads.FullState) m.payload;
                synchronized(shapes){ shapes.clear(); shapes.addAll(fs.shapes); }
                System.out.println("[SERVER] Manager opened file with " + fs.shapes.size() + " shapes");
                broadcast(new Message(MessageType.FULL_STATE,new SharedPayloads.FullState(new ArrayList<>(shapes)),"SERVER"),null);
                break;
            case NEW_BOARD:
                synchronized(shapes){ shapes.clear(); }
                System.out.println("[SERVER] Manager created new board");
                broadcast(new Message(MessageType.FULL_STATE,new SharedPayloads.FullState(new ArrayList<>(shapes)),"SERVER"),null);
                break;
            case CLOSE_BOARD:
                System.out.println("[SERVER] Manager closed board");
                broadcast(new Message(MessageType.SHUTDOWN,"Manager closed board","SERVER"),null);
                stop();
                break;
            default: break;
        }
    }
}