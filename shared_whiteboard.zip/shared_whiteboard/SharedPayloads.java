// SharedPayloads.java
// Common payload classes used by both Server and Client

import java.io.Serializable;
import java.util.List;

public class SharedPayloads {
    
    public static class JoinResponse implements Serializable {
        private static final long serialVersionUID = 1L;
        public final boolean accepted;
        public final String reason;
        
        public JoinResponse(boolean accepted, String reason) {
            this.accepted = accepted;
            this.reason = reason;
        }
    }
    
    public static class FullState implements Serializable {
        private static final long serialVersionUID = 1L;
        public final List<ShapeRecord> shapes;
        
        public FullState(List<ShapeRecord> shapes) {
            this.shapes = shapes;
        }
    }
    
    public static class ApprovalResult implements Serializable {
        private static final long serialVersionUID = 1L;
        public final String username;
        public final boolean accept;
        
        public ApprovalResult(String username, boolean accept) {
            this.username = username;
            this.accept = accept;
        }
    }
    
    public static class ChatMessage implements Serializable {
        private static final long serialVersionUID = 1L;
        public final String fromUser;
        public final String message;
        
        public ChatMessage(String fromUser, String message) {
            this.fromUser = fromUser;
            this.message = message;
        }
    }
    
    public static class DrawingActivity implements Serializable {
        private static final long serialVersionUID = 1L;
        public final String username;
        public final boolean isDrawing;  // true = started drawing, false = stopped
        
        public DrawingActivity(String username, boolean isDrawing) {
            this.username = username;
            this.isDrawing = isDrawing;
        }
    }
}